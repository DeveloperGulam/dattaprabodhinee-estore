<!-- Body Start -->
	<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Contact Us</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-6">
						<div class="panel-group accordion" id="accordion0">
							<!--<div class="panel panel-default">
								<div class="panel-heading" id="headingOne">
									<div class="panel-title">
										<a class="collapsed" data-toggle="collapse" data-target="#collapseOne" href="#" aria-expanded="false" aria-controls="collapseOne">
											<i class="uil uil-location-point chck_icon"></i>East
										</a>
									</div>
								</div>
								<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion0" style="">
									<div class="panel-body">
										Head Office Address:<br>
										मुंबई दत्तप्रबोधिनी पूजा भांडार.प्रोग्रेसिव्ह सी.शाँप नं.7.तळमजला. दत्ताराम लाड मार्ग. चिंतामणी गणपती शेजारी. चिंचपोकळी.<br/> मुंबई- 40012.<br>
										<div class="color-pink">Tel: +91 85912 44713</div>
									</div>
								</div>
							</div>-->
							<div class="panel panel-default">
								<div class="panel-heading" id="headingTwo">
									<div class="panel-title">
										<a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" href="#" aria-expanded="false" aria-controls="collapseTwo">
											<i class="uil uil-location-point chck_icon"></i>West Region Maharashtra
										</a>
									</div>
								</div>
								<div id="collapseTwo" class="panel-collapse " role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion0">
									<div class="panel-body">
									    Head Office Address:<br>
										Dattaprabodhinee Nyas, Regency Plaza, B-117, Kalyan Ambernath Rd.<br/> Kalyan- 421003.<br>
										<div class="color-pink">Tel: +91 9834009156</div>
										<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15068.340933703927!2d73.1473847!3d19.2351168!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6c62cc3ac111e8b6!2sDattaprabodhinee%20E-store!5e0!3m2!1sen!2sin!4v1612342878364!5m2!1sen!2sin" width="100%" height="100" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe><br/><br/>
									    Mumbai Estore Address:<br>
										मुंबई दत्तप्रबोधिनी पूजा भांडार.प्रोग्रेसिव्ह सी.शाँप नं.7.तळमजला. दत्ताराम लाड मार्ग. चिंतामणी गणपती शेजारी. चिंचपोकळी.<br/> मुंबई- 40012.<br>
										<div class="color-pink">Tel: +91 8591244713</div>
										<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15090.796025425912!2d72.8332457!3d18.9888959!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x83ff64662eb6dee8!2sDattaprabodhinee%20Pooja%20Bhandar%20-%20Mumbai!5e0!3m2!1sen!2sin!4v1612343281986!5m2!1sen!2sin" width="100%" height="100" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe><br/><br/>
										Nashik Estore Address:<br>
										नाशिक. दत्तप्रबोधिनी पूजा भांडार.शॉप नंबर 3. रामराज्य संकुल. काळाराम मंदिर. उत्तर दरवाजा. पंचवटी. नाशिक.<br>
										<div class="color-pink">Tel: +91 8888952130</div>
										<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3749.0384482012273!2d73.79562423478515!3d20.00690096804136!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddea54af93f661%3A0x24d9baa56b890e57!2sShri%20Kalaram%20Sansthan%20Mandir%20Vedic%20Puja%20Spiritual%20center!5e0!3m2!1sen!2sin!4v1614776074231!5m2!1sen!2sin" width="100%" height="100" style="border:0;" allowfullscreen="" loading="lazy"></iframe><br/><br/>
										Nagpur Estore Address :<br>
										नागपूर. दत्तप्रबोधिनी पूजा भांडार.साईलीला एनक्लेव्ह. परिवर्तन चौक. बेसा रोड.मानेवाडा. नागपूर<br>
										<div class="color-pink">Tel: +91 7744908751</div>
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3722.270308833315!2d79.09962961493385!3d21.101786885958894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDA2JzA2LjQiTiA3OcKwMDYnMDYuNiJF!5e0!3m2!1sen!2sin!4v1614775934891!5m2!1sen!2sin" width="100%" height="100" style="border:0;" allowfullscreen="" loading="lazy"></iframe><br/><br/>
										Pune Estore Address :<br>
										पुणे. दत्तप्रबोधिनी पूजा भांडार.शाँप नं.5. बांदल कँपिटल. कोथरूड बस डेपो. कोथरूड. पुणे.<br><br>
										<div class="color-pink">Tel: +91 9156977819</div>
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.471486821188!2d73.79299511484255!3d18.507583987416517!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf7e6c4b6a2d%3A0xbce5871c5650a92c!2sDattaprabodhinee%20E-store%20Pune!5e0!3m2!1sen!2sin!4v1614774549010!5m2!1sen!2sin" width="100%" height="100" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
									</div>
								</div>
							</div>
							<!--<div class="panel panel-default">
								<div class="panel-heading" id="headingThree">
									 <div class="panel-title">
										<a class="collapsed" data-toggle="collapse" data-target="#collapseThree" href="#" aria-expanded="false" aria-controls="collapseThree">
											<i class="uil uil-location-point chck_icon"></i>South
										</a>
									</div>
								</div>
								<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion0">
									<div class="panel-body">
										South Branch :<br>
										नागपूर. दत्तप्रबोधिनी पूजा भांडार.साईलीला एनक्लेव्ह. परिवर्तन चौक. बेसा रोड.मानेवाडा. नागपूर<br>
										<div class="color-pink">Tel: +91 7744908751</div>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading" id="headingfour">
									<div class="panel-title">
										<a class="collapsed" data-toggle="collapse" data-target="#collapsefour" href="#" aria-expanded="false" aria-controls="collapsefour">
											<i class="uil uil-location-point chck_icon"></i>North
										</a>
									</div>
								</div>
								<div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfour" data-parent="#accordion0">
									<div class="panel-body">
										North Branch :<br>
										पुणे. दत्तप्रबोधिनी पूजा भांडार.शाँप नं.5. बांदल कँपिटल. कोथरूड बस डेपो. कोथरूड. पुणे.<br><br>
										<div class="color-pink">Tel: +91 9156977819</div>
									</div>
								</div>
							</div>-->				
						</div>
					</div>
					<div class="col-lg-6 col-md-6">
						<div class="contact-title">
							<h2>Submit customer service request</h2>
							<?php if($this->session->flashdata('msg')){ ?>
							<!--<div class="alert alert-success" role="alert">
							  <?php// echo $this->session->flashdata('msg'); ?>
							</div>-->
							<script>
                                swal({
                                    title: "Done",
                                    text: "<?php echo $this->session->flashdata('msg'); ?>",
                                    timer: 1500,
									icon: "success",
                                    button: false,
                                    type: 'success'
                                });
                            </script>
							<?php } ?>
							<p>If you have a question about our service or have an issue to report, please send a request and we will get back to you as soon as possible.</p>
						</div>
						<div class="contact-form">
							<form action="<?php echo base_url('Welcome_controller/contact');?>" method="post">
								<div class="form-group mt-1">
									<label class="control-label">Full Name*</label>
									<div class="ui search focus">
										<div class="ui left icon input swdh11 swdh19">
											<input class="prompt srch_explore" type="text" name="name" id="sendername" required="" placeholder="Your Full Name">															
										</div>
									</div>
								</div>
								<div class="form-group mt-1">
									<label class="control-label">Email Address*</label>
									<div class="ui search focus">
										<div class="ui left icon input swdh11 swdh19">
											<input class="prompt srch_explore" type="email" name="email" id="emailaddress" required="" placeholder="Your Email Address">															
										</div>
									</div>
								</div>
								<div class="form-group mt-1">
									<label class="control-label">Subject*</label>
									<div class="ui search focus">
										<div class="ui left icon input swdh11 swdh19">
											<input class="prompt srch_explore" type="text" name="subject" id="sendersubject" required="" placeholder="Subject">															
										</div>
									</div>
								</div>
								<div class="form-group mt-1">	
									<div class="field">
										<label class="control-label">Message*</label>
										<textarea rows="2" class="form-control" id="message" name="message" required="" placeholder="Write Message"></textarea>
									</div>
								</div>
								<button class="next-btn16 hover-btn mt-3" name="save" type="submit" data-btntext-sending="Sending...">Submit Request</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
	<!-- Body End -->
	
