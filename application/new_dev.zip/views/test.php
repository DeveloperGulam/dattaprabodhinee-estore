<html>
<head>
        <title>My Blog</title>
</head>
<body>
        <h1>Welcome to my Blog!</h1>
        <p>Hi, <?php echo $customer_name;?></p>
</body>
</html>