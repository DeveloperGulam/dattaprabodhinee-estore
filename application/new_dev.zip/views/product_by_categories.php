<!-- Filter Right Sidebar Offset Start-->
	<!--<div class="bs-canvas bs-canvas-right position-fixed bg-cart h-100">
		<div class="bs-canvas-header side-cart-header p-3 ">
			<div class="d-inline-block  main-cart-title">Filters</div>
			<button type="button" class="bs-canvas-close close" aria-label="Close"><i class="uil uil-multiply"></i></button>
		</div> 
		<div class="bs-canvas-body filter-body">
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Categories</h4>
				</div>
				<div class="filter-item-body scrollstyle_4">
					<div class="cart-radio">
						<ul class="cte-select">
							<li>
								<input type="radio" id="c1" name="category1">
								<label for="c1">All</label>
							</li>
							<li>
								<input type="radio" id="c2" name="category1" checked>
								<label for="c2">Vegetables & Fruits</label>
							</li>
							<li>
								<input type="radio" id="c3" name="category1">
								<label for="c3">Grocery & Staples</label>
							</li>
							<li>
								<input type="radio" id="c4" name="category1">
								<label for="c4">Dairy & Eggs</label>
							</li>
							<li>
								<input type="radio" id="c5" name="category1">
								<label for="c5">Beverages</label>
							</li>
							<li>
								<input type="radio" id="c6" name="category1">
								<label for="c6">Snacks</label>
							</li>
							<li>
								<input type="radio" id="c7" name="category1">
								<label for="c7">Home Care</label>
							</li>
							<li>
								<input type="radio" id="c8" name="category1">
								<label for="c8">Noodles & Sauces</label>
							</li>
							<li>
								<input type="radio" id="c9" name="category1">
								<label for="c9">Personal Care</label>
							</li>
							<li>
								<input type="radio" id="c10" name="category1">
								<label for="c10">Pat Care</label>
							</li>
							<li>
								<input type="radio" id="c11" name="category1">
								<label for="c11">Mea & Seafood</label>
							</li>
							<li>
								<input type="radio" id="c12" name="category1">
								<label for="c12">Electronics</label>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Brand</h4>
				</div>
				<div class="other-item-body scrollstyle_4">
					<div class="brand-list">
						<div class="search-by-catgory">
							<div class="ui search">
							  <div class="ui left icon input swdh10">
								<input class="prompt srch10" type="text" placeholder="Search by brand..">
								<i class="uil uil-search-alt icon icon1"></i>
							  </div>
							</div>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_1">
							<label class="custom-control-label" for="brand_1">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_2">
							<label class="custom-control-label" for="brand_2">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_3">
							<label class="custom-control-label" for="brand_3">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_4">
							<label class="custom-control-label" for="brand_4">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_5">
							<label class="custom-control-label" for="brand_5">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_6">
							<label class="custom-control-label" for="brand_6">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_7">
							<label class="custom-control-label" for="brand_7">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_8">
							<label class="custom-control-label" for="brand_8">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_9">
							<label class="custom-control-label" for="brand_9">Brand Name</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="brand_10">
							<label class="custom-control-label" for="brand_10">Brand Name</label>
						</div>
					</div>
				</div>
			</div>
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Price</h4>
				</div>
				<div class="price-pack-item-body scrollstyle_4">
					<div class="brand-list">
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_1">
							<label class="custom-control-label" for="price_1">Less than $2 <span class="webproduct">(9)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_2">
							<label class="custom-control-label" for="price_2">$2 to $5 <span class="webproduct">(8)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_3">
							<label class="custom-control-label" for="price_3">$6 to $10 <span class="webproduct">(12)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_4">
							<label class="custom-control-label" for="price_4">$11 to $15 <span class="webproduct">(4)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_5">
							<label class="custom-control-label" for="price_5">$15 to $20 <span class="webproduct">(16)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_6">
							<label class="custom-control-label" for="price_6">$21 to $25 <span class="webproduct">(18)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="price_7">
							<label class="custom-control-label" for="price_7">More than $25 <span class="webproduct">(25)</span></label>
						</div>
					</div>
				</div>
			</div>
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Discount</h4>
				</div>
				<div class="offer-item-body scrollstyle_4">
					<div class="brand-list">
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="offer_1">
							<label class="custom-control-label" for="offer_1">2% - 5% <span class="webproduct">(9)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="offer_2">
							<label class="custom-control-label" for="offer_2">6% - 10% <span class="webproduct">(5)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="offer_3">
							<label class="custom-control-label" for="offer_3">11% - 15% <span class="webproduct">(11)</span></label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="offer_4">
							<label class="custom-control-label" for="offer_4">16% - 25% <span class="webproduct">(27)</span></label>
						</div>
					</div>
				</div>
			</div>
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Pack Size</h4>
				</div>
				<div class="price-pack-item-body scrollstyle_4">
					<div class="brand-list">
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_1">
							<label class="custom-control-label" for="pack_1">1 pc</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_2">
							<label class="custom-control-label" for="pack_2">1 pc approx. 400 to 600 gm</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_3">
							<label class="custom-control-label" for="pack_3">1 pc approx. 500 to 800 gm</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_4">
							<label class="custom-control-label" for="pack_4">Combo 3 Items</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_5">
							<label class="custom-control-label" for="pack_5">Combo 4 Items</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_6">
							<label class="custom-control-label" for="pack_6">Combo 5 Items</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_7">
							<label class="custom-control-label" for="pack_7">2 pcs</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_8">
							<label class="custom-control-label" for="pack_8">100 g</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_9">
							<label class="custom-control-label" for="pack_9">200 g</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_10">
							<label class="custom-control-label" for="pack_10">250 g</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_11">
							<label class="custom-control-label" for="pack_11">500g</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_12">
							<label class="custom-control-label" for="pack_12">1kg</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_13">
							<label class="custom-control-label" for="pack_13">2kg</label>
						</div>
						<div class="custom-control custom-checkbox pb2">
							<input type="checkbox" class="custom-control-input" id="pack_14">
							<label class="custom-control-label" for="pack_14">3kg</label>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>-->
	<!-- Filter Right Sidebar Offsetl End-->
<?php $total_category_price=0;
foreach($new_products as $latest_products){
    $total_category_price+=$latest_products->price;
}?>
<!-- Body Start -->
	<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php echo $category_name->name;?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-top-dt">
							<div class="product-left-title">
								<h2> <span class="text-danger">MRP - <?php echo $total_category_price;?></span></h2>
							</div>
						<!--	<a href="#" class="filter-btn pull-bs-canvas-right">Filters</a>
							<div class="product-sort">
								<div class="ui selection dropdown vchrt-dropdown">
									<input name="gender" type="hidden" value="default">
									<i class="dropdown icon d-icon"></i>
									<div class="text">Popularity</div>
									<ul class="menu" id="filterItem" onclick="Filter()">
										<li class="item" data-value="0">Popularity</li>
										<li class="item" data-value="1"><a href="<?php //echo base_url('Welcome_controller/filter/'); ?>">Price - Low to High</a></li>
										<li class="item" data-value="2">Price - High to Low</li>
										<li class="item" data-value="3">Alphabetical</li>
										<li class="item" data-value="4">Saving - High to Low</li>
										<li class="item" data-value="5">Saving - Low to High</li>
										<li class="item" data-value="6">% Off - High to Low</li>
									</ul>
								</div>
							</div>-->
						</div>
					</div>
				</div>
<script>
    $(document).ready(function(){
        $("#insert_delivery_timing").submit(function(e){
            e.preventDefault();
            var delivery_timing = $("input[name='delivery_timing']:checked").val();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('Welcome_controller/orders'); ?>",
                data: {delivery_timing:delivery_timing},
                success:function(data)
                {
                    alert('SUCCESS!!');
                },
                error:function()
                {
                    alert('fail');
                }
            });
        });
    });
	function Filter()
	{
		var value=$('#filterItem li').val();
		alert(value);
	}
</script>
				<div class="product-list-view">
					<div class="row">
					<?php foreach($cart_products as $products){ }?>
					<?php $count=0;
					foreach($new_products as $latest_products){
						$count++; 
						if($count>0){?>
						<div class="col-lg-3 col-md-6">
							<div class="product-item mb-30">
								<a href="<?php echo base_url('details/').strtolower(str_replace(' ', '-',$latest_products->id)).'/'.strtolower(str_replace(' ', '-',$latest_products->name));?>" class="product-img">
									<img height="155px" src="<?php if($latest_products->product_img==''){
									    echo base_url('assets/images/product.jpg');
									}
									else{
									    echo base_url('assets/images/product/'.$latest_products->product_img);
									    } ?>" alt="">
									<?php
									if($latest_products->orignal_price!=='0'){
										$value=($latest_products->price*100)/$latest_products->orignal_price;
										$off=100-$value;
									}
									else
									{
									    $off='0';
									}
										?>
									<div class="product-absolute-options">
										<span class="offer-badge-1"><?php echo substr($off, 0,2); ?>% off</span>
										<!--<span class="like-icon" title="wishlist"></span>-->
									</div>
								</a>
								<div class="product-text-dt">
									<p><?php if($latest_products->stock>'0'){
												echo"Available<span>(In Stock)</span>";
											}
											else{
												echo "Not Available<span>(Out Of Stock)</span>";
											}
											?></p>
									<h4><?php echo $latest_products->name; ?></h4>
									<div class="product-price">₹<?php echo $latest_products->price; ?> <span>₹<?php echo $latest_products->orignal_price; ?></span></div>
								<?php if(!empty($products['sub_category_image'])){
									echo "";
								}
								else{?>
									<form action="<?php echo base_url('Welcome_controller/add_to_cart/'.$latest_products->id).'/home/'; ?>" method="post">
										<div class="qty-cart">
											<div class="quantity buttons_added">
												<input type="button" value="-" class="minus minus-btn">
												<input type="number" step="1" name="qty" value="1" class="input-text qty text">
												<input type="button" value="+" class="plus plus-btn">
											</div>
											<button style="border:none;background:none;" class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></button>
										</div>
										<div class="product-price mt-3"><button style="padding-top:-5px;" class="add-cart-btn hover-btn form-control"> <i class="uil uil-shopping-cart-alt"></i> Add to cart (for buy)</button></div>
									</form>
									<?php }?>
								</div>
							</div>
						</div>
					<?php }
					else{
						echo"data not found";
					}
					}?>
						<div class="col-md-12">
						<?php //echo $this->pagination->create_links(); ?>
							<div class="more-product-btn">
								<p class="" onclick="click_count()" id="data" style="display:none;">Show More</p>
								<!--<button class="show-more-btn hover-btn" onclick="click_count()" id="offset">Show More</button>-->
								<!--<button class="show-more-btn hover-btn" onclick="window.location.href = '<?php echo base_url("shop-by-categories/".strtolower(str_replace(' ', '-',$latest_products->category))); ?>';">Show More</button>-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
	var clicks = 0;
	function click_count(){
		clicks += 1;
		$('#data').show();
		$('#offset').hide();
		document.getElementById("data").innerHTML = 'No more data found.';
	}
	// $(document).ready(function(){
		// var limit=1;
		// var start=0;
		// var action='inactive';
		// function load_country_data(limit,start)
		// {
			// $.ajax({
				// url:"<?php echo base_url('Welcome_controller/fetchdata'); ?>",
				// method:"POST",
				// data{limit:limit, start:start},
				// cache:false,
				// success:function(data)
				// {
					// $('#load_data').append($data);
					// if(data=='')
					// {
						// $('#load_data_msg').html('No More');
					// }
				// }
			// });
		// }
		// if(action=='inactive'){
			// action='active';
			// load_country_data(limit,start);
		// }
		// $(window).scroll(function(){
			// alert('ok');
			// if($(window).scrollTop() + $(window).height() > $('#load_data').height() && action=='inactive')
			// {
				// action='active';
				// start=start+limit;
				// setTimeout(function(){
					// load_country_data(limit,start);
				// }, 1000);
			// }
		// })
	// });
	</script>
	<!-- Body End -->