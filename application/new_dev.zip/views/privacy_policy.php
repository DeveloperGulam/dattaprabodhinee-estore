<!-- Body Start -->
	<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="index.html">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="job-main-dt">
							<h2>Dattaprabodhinee Estore Privacy Policy</h2>
							<span>Read this privacy policy.</span>
						</div>
						<div class="job-des-dt142 policy-des-dt">
							<h4>Privacy Policy:</h4>
							<p>The User hereby consents, expresses and agrees that he has read and fully understands the Privacy Policy of www.Dattaprabodhinee.com. The user further consents that the terms and contents of such Privacy Policy are acceptable to him.</p>
						</div>
						
					</div>
				</div>
			</div>
		</div>	
	</div>
	<!-- Body End -->