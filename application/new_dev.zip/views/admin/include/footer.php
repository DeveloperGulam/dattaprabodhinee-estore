<footer class="py-4 bg-footer mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted-1">© 2020 <b>E-Store</b>. by <a href="https://www.dattaprabodhinee.org">Dattaprabodhinee</a></div>
                            <div class="footer-links">
                                <a href="#">Privacy Policy</a>
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
        <script src="<?php echo base_url('assets/admin/vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/vendor/chart/highcharts.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/vendor/chart/exporting.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/vendor/chart/export-data.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/vendor/chart/accessibility.js');?>"></script>
        <script src="<?php echo base_url('assets/admin/js/scripts.js');?>"></script>
        <script src="<?php echo base_url('assets/admin/js/chart.js');?>"></script>
		
		<!-- froala Editor Javascripts -->
		<script type="text/javascript" src="<?php echo base_url('assets/admin/ajax/libs/codemirror/5.3.0/codemirror.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/froala_editor.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/align.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/code_beautifier.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/code_view.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/colors.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/emoticons.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/draggable.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/font_size.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/font_family.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/image.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/file.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/image_manager.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/line_breaker.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/link.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/lists.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/paragraph_format.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/paragraph_style.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/video.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/table.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/url.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/entities.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/char_counter.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/inline_style.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/save.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/fullscreen.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/admin/vendor/froala_editor_3.1.1/js/plugins/quote.min.js');?>"></script>
		<script>
			(function () {
			  new FroalaEditor("#edit", {
				zIndex: 10
			  })
			})()
		</script>
       
    </body>
</html>
